//
//  SearchViewController.swift
//  BubblePop
//
//  Created by Aung Kaung Myat on 22/5/21.
//  Copyright © 2021 Aung Kaung Myat. All rights reserved.
//

import UIKit
let search = UISearchController()
class SearchViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.searchController = search

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
