//
//  GamePlayViewController.swift
//  BubblePop
//
//  Created by Aung Kaung Myat on 25/4/21.
//

import UIKit

class GamePlayViewController: UIViewController {
    //add a view to mark position
    @IBOutlet weak var bubbleView: UIView!
    //a label to show highscore
    @IBOutlet weak var highestScoreLbl: UILabel!
    //a label to show time count
    @IBOutlet weak var timerLabel: UILabel!
    //a label to show scores in gameplay
    @IBOutlet weak var scoreLbl: UILabel!
    //a view to show 3-2-1 countdown label
    @IBOutlet weak var countDownView: UIView!
    //a label to count 3-2-1
    @IBOutlet weak var countDownlabel: UILabel!
    
    var gameTimer = Timer() //a timer object
    var playerName:String = ""//a string variable to get name value from settingVC
    var remainingGameTime:Int = 0//Int var to use as remining time in timer
    var gameScore = 0//score of the player
    var lastColor:BubbleColor = .red//last color of the bubble the player popped
    var numOfBubbles = 0//int to store number of bubbles from slider in setting VC
    var bubbleArray = [Bubble]()//array to store,remove bubbles
    var players = [[String]]()//array to store players
    var count = 3//label for counter 3-2-1
    var preCounter = Timer()//a timer object
    var segmentValue = true//Bool value to select animation
    var setTime = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //return sorted array players values
        if let item = UserDefaults.standard.value(forKey: "players") as? [[String]]{
            self.players = item
        }
        //show counting timer
        timerLabel.text = String(remainingGameTime)
        //show highest score from array
        if (players.count != 0){
            highestScoreLbl.text = players[0][1]
        }
        //counter for time and appear ballons
        preCounter = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { [self]
            timer in
            self.countDown()
        }
        
    }
    
    //function for game timer countdown
    @objc func counting() {
        
        remainingGameTime -= 1
        timerLabel.text = String(remainingGameTime)
        
        if remainingGameTime == 0 {
            gameTimer.invalidate()
            players.append([playerName, scoreLbl.text!])
            
            let vc = storyboard?.instantiateViewController(identifier: "HighScoreViewController") as! HighScoreViewController
            self.navigationController?.pushViewController(vc, animated: true)
            vc.navigationItem.setHidesBackButton(true, animated: true)
        }
    }
    //function for 3-2-1 countdown
    @objc func countDown(){
        count -= 1
        countDownlabel.text = String(count)
        
        if count == 0 {
            preCounter.invalidate()
            countDownlabel.removeFromSuperview()
            countDownView.removeFromSuperview()
            gameTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { [self]
                timer in
                refreshBubble()
                if remainingGameTime <= setTime/2{
                    applyVelocity()
                }
                counting()
                UserDefaults.standard.set(players, forKey: "players")//pass player data after counting
            }
            
            
        }
        
    }
    //function to make the bubbles go faster
    func applyVelocity(){
        
        gameTimer = Timer.scheduledTimer(withTimeInterval : 1.5, repeats: true, block: { (timer) in
            self.refreshBubble()
        })
    }
    
    //a fucntion to generate bubble
    @objc func generateBubble(){
        let bubble = Bubble()
        bubble.frame = CGRect(x:Int.random(in: Int(bubbleView.frame.minX) ... Int(bubbleView.frame.maxX)), y: Int.random(in: Int(bubbleView.frame.minY)...Int(bubbleView.frame.maxY)),width: 50, height: 50)
        
        bubble.randomColor()//function called from Bubble class
        if(!isOverlap(button: bubble)){
            bubbleArray.append(bubble)
            //animation selection according to user input
            if segmentValue == true {
                bubble.animation()
            }
            else if segmentValue == false {
                bubble.flash()
            }
            bubble.addTarget(self, action: #selector(bubblePressed), for: .touchUpInside)
            self.view.addSubview(bubble)
        }
    }
    //to check intersection/overlapping
    func isOverlap (button: UIButton) -> Bool{
        let bubbles = bubbleArray
        for bubble in bubbles{
            if (button.frame.intersects(bubble.frame)){
                return true
            }
        }
        return false
    }
    //loop bubble generation according to user input
    @objc func addBubble(){
        let randomGenerate = Int.random(in: 1...numOfBubbles-bubbleArray.count)
        for _ in 1...randomGenerate{
            generateBubble()
        }
    }
    //remove random bubbles from view
    @objc func removeBubble(){
        if (bubbleArray.count > 0){
            let randomRemove = Int.random(in:1...bubbleArray.count)
            for _ in 1...randomRemove{
                let lastBubble:Bubble = bubbleArray.last!
                lastBubble.removeFromSuperview()
                bubbleArray.removeLast()
                
            }
        }
    }
    //remove and add sequence
    @objc func refreshBubble(){
        removeBubble()
        addBubble()
    }
    
    //function for action after bubble is pressed
    @IBAction func bubblePressed(_ sender: Bubble) {
        // remove pressed bubble from view
        sender.removeFromSuperview()
        
        if (sender.color == lastColor && gameScore != 0){
            gameScore = gameScore + Int(round(1.5*Double(sender.getScore())))
        }
        else{
            gameScore += sender.getScore()
        }
        scoreLbl.text = String(gameScore)
        lastColor = sender.color
        let i = bubbleArray.firstIndex(where: {$0 == sender})!
        bubbleArray.remove(at: i)
    }
    
    
}

