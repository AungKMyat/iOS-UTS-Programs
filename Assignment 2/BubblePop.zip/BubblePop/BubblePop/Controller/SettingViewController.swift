//
//  SettingViewController.swift
//  BubblePop
//
//  Created by Aung Kaung Myat on 24/4/21.
//

import UIKit

class SettingViewController: UIViewController {
    
    //connect  slider to select time
    @IBOutlet weak var timerSlide: UISlider!
    //connect label to show time value
    @IBOutlet weak var timerLbl: UILabel!
    //connect button to edit appearance
    @IBOutlet weak var startBtn: UIButton!
    //connect text field to input name
    @IBOutlet weak var nameTxtField: UITextField!
    //connect slider to edit balloon number
    @IBOutlet weak var bubbleNumber: UISlider!
    //connect label to show slider value
    @IBOutlet weak var bubbleNumberLbl: UILabel!
    //connect segmented control to select animation
    @IBOutlet weak var animationSegment: UISegmentedControl!
    var animationSelect = true //Bool to control animation choice
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //add a round corner for the button
        startBtn.layer.cornerRadius = 10.0
        //set the default value of the timer to 60
        timerSlide.value = 60
        //show the default time value
        timerLbl.text = String(Int(timerSlide.value))
        //set default number of bubbles
        bubbleNumber.value = 15
        //show the value of slider on the screen
        bubbleNumberLbl.text = String(Int(bubbleNumber.value))
        
    }
    //a function to show time value when the slider is used 
    @IBAction func timerSliderValueChanged(_ sender: Any) {
        self.timerLbl.text = String(Int(self.timerSlide.value))//take the value of slider to timer label
    }
    
    //segemented control function to choose animation mode
    @IBAction func animationSeg(_ sender: Any) {
        
        if animationSegment.selectedSegmentIndex == 0{
            animationSelect = true
        }
        else if animationSegment.selectedSegmentIndex == 1{
            animationSelect = false
        }
        
    }
    
    //slider function to change bubble number and make the label show
    @IBAction func bubbleNumberSlider(_ sender: Any) {
        self.bubbleNumberLbl.text = String(Int(self.bubbleNumber.value))//take the value of slider to bubble numbers label
    }
    //function to send data from VC to another VC(GamePlayVC)
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "goToGame" {
            let VC = segue.destination as! GamePlayViewController
            VC.playerName = String(nameTxtField.text!)//send the name value from label to gameVC
            VC.remainingGameTime = Int(timerSlide.value)//send the time value from slider to gameVC
            VC.numOfBubbles = Int(bubbleNumber.value)//send the number of bubbles set on sliders to gameVC
            VC.segmentValue = animationSelect
            VC.setTime = Int(timerSlide.value)
        }
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
