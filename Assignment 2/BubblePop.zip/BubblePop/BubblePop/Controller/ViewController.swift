//
//  ViewController.swift
//  BubblePop
//
//  Created by Aung Kaung Myat on 22/4/21.
//

import UIKit

class ViewController: UIViewController {
    //connect New Game button 
    @IBOutlet weak var NewGame: UIButton!
    //connect View Highscore button
    @IBOutlet weak var viewHS: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //add a round corner for the button
        NewGame.layer.cornerRadius = 10.0
        //add a round corner for the button
        viewHS.layer.cornerRadius = 10.0
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: animated)
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(false, animated: animated)
    }
    
}

