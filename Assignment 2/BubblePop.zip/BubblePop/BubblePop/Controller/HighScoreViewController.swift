//
//  HighScoreViewController.swift
//  BubblePop
//
//  Created by Aung Kaung Myat on 27/4/21.
//  Copyright © 2021 Aung Kaung Myat. All rights reserved.
//

import UIKit

class HighScoreViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    //table view to add cells of players
    @IBOutlet weak var highScoreView: UITableView!
    //2d array to store player data
    var players = [[String]]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //store user data in array if ther is one
        if let item = UserDefaults.standard.value(forKey: "players") as? [[String]]{
            self.players = item
        }
        //sort user array from highest score
        players.sort { Int($0[1]) ?? 0 > Int($1[1]) ?? 0 }
        //store sorted user value
        UserDefaults.standard.set(players, forKey: "players")
        //create a nib object of cell
        let nib = UINib(nibName: "HighScoreTableViewCell", bundle: nil)
        //regiester nib to the view
        highScoreView.register(nib, forCellReuseIdentifier: "HighScoreTableViewCell")
        highScoreView.delegate = self
        highScoreView.dataSource = self
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("")
    }
    //number of rows
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        players.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = highScoreView.dequeueReusableCell(withIdentifier: "HighScoreTableViewCell",for: indexPath) as! HighScoreTableViewCell
        
        cell.nameCellLbl.text = players[indexPath.row][0]
        cell.scoreCellLbl.text = players[indexPath.row][1]
        return cell
    }
    
}







