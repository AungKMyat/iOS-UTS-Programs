//
//  Bubble.swift
//  BubblePop
//
//  Created by Aung Kaung Myat on 25/4/21.
//

import UIKit

//an enum to keep the bubble colors and scores together
enum BubbleColor : Int{
    case red = 1, pink = 2, green = 5, blue = 8, black = 10
}

class Bubble: UIButton{
    //declaring variables for the color and position of the bubble
    var xPosition = 0
    var yPosition = 0
    var color:BubbleColor = .red
    
  
    //initialising the bubble button
    override init(frame:CGRect) {
        super.init(frame:frame)
        self.backgroundColor = .red
        self.frame = CGRect(x: xPosition, y: yPosition, width: 50, height: 50)
        self.layer.cornerRadius = 0.5 * self.bounds.size.width
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    //animation for appearing bubble
    func animation() {
        let springAnimation = CASpringAnimation(keyPath: "transform.scale")
        springAnimation.duration = 0.6
        springAnimation.fromValue = 1
        springAnimation.toValue = 0.8
        springAnimation.repeatCount = 1
        springAnimation.initialVelocity = 0.5
        springAnimation.damping = 1
        
        layer.add(springAnimation, forKey: nil)
    }
    
    //animation flash for appearing bubble
    func flash() {
        
        let flash = CABasicAnimation(keyPath: "opacity")
        flash.duration = 0.2
        flash.fromValue = 1
        flash.toValue = 0.1
        flash.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.easeInEaseOut)
        flash.autoreverses = true
        flash.repeatCount = 3
        
        layer.add(flash, forKey: nil)
    }
    
    //function to change the color of the bubble
    func changeColor(newColor:BubbleColor){
        self.color = newColor
        switch self.color{
        case .pink:
            self.backgroundColor = .magenta
        case .black:
            self.backgroundColor = .black
        case .blue:
            self.backgroundColor = .blue
        case .green:
            self.backgroundColor = .green
        default:
            self.backgroundColor = .red
        }
    }
    
    //function to randomise the color of the bubble with their probabilities
    func randomColor(){
        let random = Int.random(in: 0...100)
        switch random{
        case 0...40:
            changeColor(newColor: .red)
        case 41...70:
            changeColor(newColor: .pink)
        case 71...85:
            changeColor(newColor: .green)
        case 86...95:
            changeColor(newColor: .blue)
        case 96...100:
            changeColor(newColor: .black)
        default:
            changeColor(newColor: .red)
        }
    }
    
    //function to get the associated score of the bubble respective to its color
    func getScore() -> Int{
        return color.rawValue
    }
    
}
